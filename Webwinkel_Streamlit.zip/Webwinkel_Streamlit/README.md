# Webwinkel-dashboard in Streamlit

Deze app toont je bestaande HTML-dashboard in een ingesloten venster.
De gegevens, grafieken, antwoorden en filters zitten in het HTML-bestand.
De berekeningen blijven uitgevoerd door het bestaande dashboard; dit is geen
herschrijving naar pandas en matplotlib. Er is geen aparte CSV nodig.

## Starten op je computer
1. Pak het ZIP-bestand uit.
2. Open de uitgepakte map in VS Code.
3. Open Terminal > New Terminal.
4. Voer uit:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open de Local URL die de terminal toont (meestal http://localhost:8501).
Het ingesloten dashboard past zijn hoogte automatisch aan.

## Bestanden
- app.py: Streamlit-app
- requirements.txt: benodigde Python-module
- Webwinkel_Dashboard_Excel.html: volledige dashboardweergave met gegevens

## Beperkingen
Deze versie toont een vaste momentopname uit het Excel-bestand. Nieuwe Excel-data
worden niet automatisch ingelezen. Online publiceren en gegevens verversen zijn
niet verbonden met deze lokale app. Dashboardacties voor Sites-publicatie en
verversing zijn geen Streamlit-hostingacties. Bewerkingen in het ingesloten venster
kunnen afhangen van browseropslag; bewaar altijd het oorspronkelijke HTML-bestand.
Deze download is niet gepubliceerd op Streamlit Community Cloud.
