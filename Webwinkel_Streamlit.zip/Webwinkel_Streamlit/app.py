"""Toon het bestaande, zelfstandige Webwinkel-dashboard in Streamlit."""
from pathlib import Path
import streamlit as st

st.set_page_config(page_title="Webwinkel · prestaties", page_icon="🛍️", layout="wide")

html_path = Path(__file__).resolve().parent / "Webwinkel_Dashboard_Excel.html"
if not html_path.is_file():
    st.error("Webwinkel_Dashboard_Excel.html ontbreekt. Zet dit bestand naast app.py.")
    st.stop()

st.iframe(html_path, height="content", alt="Webwinkel-dashboard met grafieken, filters en antwoorden")
